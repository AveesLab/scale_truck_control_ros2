#ifndef _ROS_scale_truck_control_yolo_flag_h
#define _ROS_scale_truck_control_yolo_flag_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace scale_truck_control
{

  class yolo_flag : public ros::Msg
  {
    public:
      typedef bool _run_yolo_type;
      _run_yolo_type run_yolo;

    yolo_flag():
      run_yolo(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_run_yolo;
      u_run_yolo.real = this->run_yolo;
      *(outbuffer + offset + 0) = (u_run_yolo.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->run_yolo);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_run_yolo;
      u_run_yolo.base = 0;
      u_run_yolo.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->run_yolo = u_run_yolo.real;
      offset += sizeof(this->run_yolo);
     return offset;
    }

    const char * getType(){ return "scale_truck_control/yolo_flag"; };
    const char * getMD5(){ return "d5fd0b7dc9785ff0af152c507684de3f"; };

  };

}
#endif
