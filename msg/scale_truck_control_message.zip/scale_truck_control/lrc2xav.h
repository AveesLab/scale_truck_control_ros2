#ifndef _ROS_scale_truck_control_lrc2xav_h
#define _ROS_scale_truck_control_lrc2xav_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace scale_truck_control
{

  class lrc2xav : public ros::Msg
  {
    public:
      typedef float _cur_vel_type;
      _cur_vel_type cur_vel;
      typedef float _tar_vel_type;
      _tar_vel_type tar_vel;
      typedef float _tar_dist_type;
      _tar_dist_type tar_dist;
      typedef bool _alpha_type;
      _alpha_type alpha;
      typedef bool _send_rear_camera_image_type;
      _send_rear_camera_image_type send_rear_camera_image;
      typedef uint8_t _lrc_mode_type;
      _lrc_mode_type lrc_mode;
      typedef uint8_t _crc_mode_type;
      _crc_mode_type crc_mode;

    lrc2xav():
      cur_vel(0),
      tar_vel(0),
      tar_dist(0),
      alpha(0),
      send_rear_camera_image(0),
      lrc_mode(0),
      crc_mode(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_cur_vel;
      u_cur_vel.real = this->cur_vel;
      *(outbuffer + offset + 0) = (u_cur_vel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_cur_vel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_cur_vel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_cur_vel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->cur_vel);
      union {
        float real;
        uint32_t base;
      } u_tar_vel;
      u_tar_vel.real = this->tar_vel;
      *(outbuffer + offset + 0) = (u_tar_vel.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tar_vel.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tar_vel.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tar_vel.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tar_vel);
      union {
        float real;
        uint32_t base;
      } u_tar_dist;
      u_tar_dist.real = this->tar_dist;
      *(outbuffer + offset + 0) = (u_tar_dist.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_tar_dist.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_tar_dist.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_tar_dist.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->tar_dist);
      union {
        bool real;
        uint8_t base;
      } u_alpha;
      u_alpha.real = this->alpha;
      *(outbuffer + offset + 0) = (u_alpha.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->alpha);
      union {
        bool real;
        uint8_t base;
      } u_send_rear_camera_image;
      u_send_rear_camera_image.real = this->send_rear_camera_image;
      *(outbuffer + offset + 0) = (u_send_rear_camera_image.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->send_rear_camera_image);
      *(outbuffer + offset + 0) = (this->lrc_mode >> (8 * 0)) & 0xFF;
      offset += sizeof(this->lrc_mode);
      *(outbuffer + offset + 0) = (this->crc_mode >> (8 * 0)) & 0xFF;
      offset += sizeof(this->crc_mode);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_cur_vel;
      u_cur_vel.base = 0;
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_cur_vel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->cur_vel = u_cur_vel.real;
      offset += sizeof(this->cur_vel);
      union {
        float real;
        uint32_t base;
      } u_tar_vel;
      u_tar_vel.base = 0;
      u_tar_vel.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_tar_vel.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_tar_vel.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_tar_vel.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->tar_vel = u_tar_vel.real;
      offset += sizeof(this->tar_vel);
      union {
        float real;
        uint32_t base;
      } u_tar_dist;
      u_tar_dist.base = 0;
      u_tar_dist.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_tar_dist.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_tar_dist.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_tar_dist.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->tar_dist = u_tar_dist.real;
      offset += sizeof(this->tar_dist);
      union {
        bool real;
        uint8_t base;
      } u_alpha;
      u_alpha.base = 0;
      u_alpha.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->alpha = u_alpha.real;
      offset += sizeof(this->alpha);
      union {
        bool real;
        uint8_t base;
      } u_send_rear_camera_image;
      u_send_rear_camera_image.base = 0;
      u_send_rear_camera_image.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->send_rear_camera_image = u_send_rear_camera_image.real;
      offset += sizeof(this->send_rear_camera_image);
      this->lrc_mode =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->lrc_mode);
      this->crc_mode =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->crc_mode);
     return offset;
    }

    const char * getType(){ return "scale_truck_control/lrc2xav"; };
    const char * getMD5(){ return "9dff637cdc4d0bca625074b1d66ff8fb"; };

  };

}
#endif
